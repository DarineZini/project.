package com.example.mac_os.criminalintent;


import android.os.StrictMode;
import android.support.v4.app.Fragment;

public class CrimeListActivity extends  SingleFragmentActivity {
    @Override
    protected Fragment CreateFragment() {
        // this is for removing the exception when we want perform a
        // networking operation on the app's main thread
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        Fragment fragment = new CrimeListFragment();

//        Client myClient = new Client("192.168.0.14", 5000);
//        myClient.execute();
//        System.out.println("---received value in activity ---------");
//        System.out.println(test);
        return fragment;
//        return new Fragment();
    }
}
