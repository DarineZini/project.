package com.example.mac_os.criminalintent;

import android.os.AsyncTask;
import android.support.v4.app.Fragment;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client extends AsyncTask<Void , Void,String> {


    CrimeLab crimeLab;
    String dstAddress;
    int dstPort;
    String response = "";

    Client(String addr, int port, CrimeLab crimeLab){
        dstAddress = addr;
        dstPort = port;
        this.crimeLab = crimeLab;
    }

    @Override
    protected String doInBackground(Void... voids) {
        Socket socket = null;
        try {

            socket = new Socket(dstAddress, dstPort);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
            byte[] buffer = new byte[1024];
            int bytesRead;

            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            /*
             * notice: inputStream.read() will block if no data return
             */

            while((response = reader.readLine()) != null){
                System.out.println("read" + response);
                Crime crime = new Crime(response);
                crimeLab.addCrime(crime);
            }

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "UnknownHostException: " + e.toString();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "IOException: " + e.toString();
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        return response;
    }

    protected void onPostExecute(String result){
        super.onPostExecute(result);
    }

}
