import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;
import database.CrimeDbSchema.*;


public class CrimeBaseHelper {

    public static String url = "jdbc:sqlite:/home/ghost/Documents/sqlite/";
    public static void createNewDatabase(String fileName) {

        String url = "jdbc:sqlite:/home/ghost/Documents/sqlite/" + fileName + ".db";

        try {
            Connection conn = DriverManager.getConnection(url);
            if (conn != null) {
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("A new database has been created.");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Connection connect() {
        Connection conn = null;

        try {
            // db parameters
            String urll = url+ "crimes.db";
            // create a connection to the database
            conn = DriverManager.getConnection(urll);

            System.out.println("Connection to SQLite has been established.");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return conn;
    }

    public static void createTableIfNotExist(Connection conn){

       String sql = "CREATE TABLE IF NOT EXISTS crimes ("+
//               "(_id integer primary key autoincrement, "+
               CrimeTable.Cols.UUID + " varchar(20) primary key," +
               CrimeTable.Cols.TITLE + " varchar(20)," +
               CrimeTable.Cols.DATE + " TEXT DEFAULT '2022-12-12' NOT NULL," +

               CrimeTable.Cols.SOLVED+ " DEFAULT 0 NOT NULL)";

       try{
           Statement stmt = conn.createStatement();
           stmt.execute(sql);
           System.out.println("Table Has been created");

       }catch(SQLException e){
           System.out.println("Error");
           System.out.println(e.getMessage());}

    }
    public static ArrayList<Crime> findAll(Connection con){
        ArrayList<Crime> result = new ArrayList<Crime>();
        String sqlQuery = "SELECT * FROM crimes";
        try{
//            Connection con = connect();

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sqlQuery);

            while(rs.next()){
                String title = rs.getString(CrimeTable.Cols.TITLE);
                UUID uuid ;

                title = rs.getString(CrimeTable.Cols.TITLE) ;
                uuid =UUID.fromString( rs.getString(CrimeTable.Cols.UUID) );
                String sqlDate = rs.getString(CrimeTable.Cols.DATE);
                int solvedInt = rs.getInt(CrimeTable.Cols.SOLVED);


                SimpleDateFormat dateFormat =  new SimpleDateFormat("YYYY-MM-DD");
                Date date = dateFormat.parse(sqlDate);
                System.out.println(title);
                Crime c = new Crime(uuid, title, date, solvedInt == 1);
                result.add(c);
                System.out.println("result : " + result);
            }
            rs.close();
            stmt.close();

//            conn.commit();
        }catch (Exception e){e.printStackTrace();}
        return result;
    }

    // insert if the id is not there else update the row with the same id
    public static void insert(Connection conn, Crime crime){
       try{
           Statement stmt = conn.createStatement();
           SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD");
           String sqlInsertQuery = "INSERT INTO crimes VALUES( '"
                   + crime.getId()
                   + "', '" + crime.getTitle()
                   + "', '"+ dateFormat.format(crime.getDate())+ "', "
                   + (crime.isSolved() ? 1 : 0)
                   +")";
           System.out.println(sqlInsertQuery);

           stmt.executeUpdate(sqlInsertQuery);

           stmt.close();
//           conn.commit();

       }catch(Exception ex){ex.printStackTrace();};

    }


// test connection to the database
    public static void main(String[] args) throws SQLException {

//        createNewDatabase("crimes");

        Connection conn = connect();
//        createTableIfNotExist(conn);
        Crime c1 = new Crime("Someone stole my phone" , new Date(), true);
        Crime c2 = new Crime("Someone stole my car" , new Date(), false);
        insert(conn, c2);
        System.out.println(findAll(conn));
        conn.close();

    }

}
