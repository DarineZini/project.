import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;

public class Crime implements Serializable {
    private static final long serialVersionUID = 1L;

    private String mTitle;
    private Date mDate;
    private UUID mId;
    private boolean mSolved;

    public Crime(){
        mDate = new Date();
        mId = UUID.randomUUID();
        mSolved = false;
    }

    public Crime(String message){
        String[] arrStr = message.split("%", 3);
        mId = UUID.fromString(arrStr[0]);
        mTitle = arrStr[1];
        mDate = new Date();
        mSolved = Boolean.parseBoolean(arrStr[3]);
    }

    public Crime(String mTitle, Date mDate,  boolean mSolved) {
        this.mTitle = mTitle;
        this.mDate = mDate;
        this.mId = UUID.randomUUID();
        this.mSolved = mSolved;
    }
    public Crime( UUID mId,String mTitle, Date mDate,  boolean mSolved) {
        this.mTitle = mTitle;
        this.mDate = mDate;
        this.mId = mId;
        this.mSolved = mSolved;
    }

    public String toSlugify(){
        return mId + "%" + this.mTitle + "%" + this.mDate + "%" + mSolved;
    }




    public String getTitle() {
        return mTitle;
    }

    public Date getDate() {
        return mDate;
    }

    public UUID getId() {
        return mId;
    }

    public boolean isSolved() {
        return mSolved;
    }

    public void setSolved(boolean mSolved) {
        this.mSolved = mSolved;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public void setDate(Date mDate) {
        this.mDate = mDate;
    }

    public void setId(UUID mId) {
        this.mId = mId;
    }

    @Override
    public boolean equals(Object obj) {

        if(obj != null && obj instanceof Crime)
        {
            Crime crime = (Crime) obj;
            return this.mId == crime.mId;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Crime{" +
                "mTitle='" + mTitle + '\'' +
                ", mDate=" + mDate +
                ", mId=" + mId +
                ", mSolved=" + mSolved +
                '}';
    }

}
