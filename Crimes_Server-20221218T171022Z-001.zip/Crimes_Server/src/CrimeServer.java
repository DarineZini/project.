import java.net.*;
import java.io.*;
import java.sql.Array;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;


public class CrimeServer {

    ArrayList clientOutputStreams;
    static ArrayList<Crime> crimesData ;
    public class ClientHandler implements Runnable{
        BufferedReader reader;
        Socket sock;
        public ClientHandler(Socket clientSocket){
            try{
                sock = clientSocket;
                InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(isReader);

            }catch(Exception ex){ex.printStackTrace();}
        }

        public void sendCrimes(){
             try {
                PrintWriter writer = new PrintWriter(sock.getOutputStream());

                 for (Crime crime : crimesData){
                     System.out.println(crime.toSlugify());
                     writer.println(crime.toSlugify());
                     writer.flush();
                 }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        public void run(){
            String message;
            sendCrimes();
            try{
                while(( message = reader.readLine()) != null ){
                    System.out.println(sock.getInetAddress() + " : " + message);
                    crimesData.add(new Crime(message));
                    tellEveryApp(message);
                }
            }catch(Exception ex){ex.printStackTrace();}
        }
    }

    public static void main(String[] args){

        // connecting to the database
        Connection conn = CrimeBaseHelper.connect();

        // get all the data from the sqlite database
        crimesData = CrimeBaseHelper.findAll(conn);
        System.out.println(crimesData);
        new CrimeServer().go();
    }

    public void go(){
        clientOutputStreams = new ArrayList();

        try{
            ServerSocket serverSocket = new ServerSocket(5000);

            while(true){
                Socket clientSocket = serverSocket.accept();
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream());

                clientOutputStreams.add(writer);

                Thread t = new Thread(new ClientHandler(clientSocket));
                t.start();
                System.out.println("got a connection " + clientSocket.getInetAddress());
            }
        }catch(Exception ex){ex.printStackTrace();}
    }

    public void tellEveryApp(String message){
        Iterator it = clientOutputStreams.iterator();
        while(it.hasNext()) {
            try {
                PrintWriter writer = (PrintWriter) it.next();
                writer.println(message);
                writer.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}
